#include "Biblioteca.h"

Biblioteca::Biblioteca()
{
}

Biblioteca::~Biblioteca()
{
}

void Biblioteca::operator<<(Libro* l)
{
	libros.registrar(l);
}

Libro* Biblioteca::operator[](int posicion)
{
	return libros[posicion];
}

Libro* Biblioteca::buscar(int cod)
{
	Libro Codbus(cod);
	Libro* cEncontrado = libros.buscar(&Codbus);
	return cEncontrado;
}

void Biblioteca::registrarPrestamoSimple(int id, int ci, int codLibro, int fechaIni, int fechaDev)
{
	Libro* l = buscar(codLibro);
	Socio* s = SingletonSocios::getInst().buscar(ci);
	if (l != NULL && s != NULL)
	{
		prestamos.registrar(new PrestamoSimple(id, s, l, fechaIni, fechaDev));
	}
}

void Biblioteca::registrarPrestamoRenovado(int id, int ci, int codLibro, int fechaIni, int fechaDev, int nuevaFech, string motivo)
{
	Libro* l = buscar(codLibro);
	Socio* s = SingletonSocios::getInst().buscar(ci);
	if (l != NULL && s != NULL)
	{
		prestamos.registrar(new PrestamoRenovado(id, s, l, fechaIni, fechaDev,nuevaFech,motivo));
	}
}

string Biblioteca::toString()
{
	libros.ordenar(Libro::CompCod);
	prestamos.ordenar(Prestamo::ComId);
	stringstream ss;
	ss << "{\"libros\":"<< libros.toJson(Libro::toString)<< ",\"prestamos\":"<< prestamos.toJson(Prestamo::toStringPres)<< "}";
	return ss.str();
}


